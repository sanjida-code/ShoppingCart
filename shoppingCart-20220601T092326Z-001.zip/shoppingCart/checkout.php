
<?php
session_start();
if(!isset($_SESSION['username']) || $_SESSION['username']=''){
    header('location: customer_login.php');
    exit();
  }
include("database.php");

// print_r($_SESSION['id']);
// exit();

$total_price = 0;
$sum_of_all_products = 0;
$order_place = '';
if(isset($_SESSION['id']))
{
    $customer_id = $_SESSION['id'];
}
if(isset($_COOKIE['shopping_cart']))
    {
        $cookie_data = stripslashes($_COOKIE['shopping_cart']);
        $cart_data = json_decode($cookie_data, true);

        $order_unique_id = 'ord-'.uniqid();
        $order_insert_sql = "INSERT INTO orders SET order_uid='$order_unique_id', customer_id='$customer_id'";

        $order_insert_res = mysqli_query($conn, $order_insert_sql);
        $ord_id = mysqli_insert_id($conn);

        // print_r($order_insert_sql);
        // exit();

        if($order_insert_res)
        {
           
            foreach($cart_data as $cart=>$values)
            {                          
                $order_product_sql = "INSERT INTO orders_products SET order_id = '$ord_id', product_id=".$values['item_id'].", p_quantity=".$values['item_quantity']; //insert in order_product table
                
                $product_res = mysqli_query($conn, $order_product_sql);
                if ($product_res)
                {
                    $product_sql = "SELECT * FROM `product` WHERE id =".$values['item_id'];

                    $product_res = mysqli_query($conn, $product_sql);
                    foreach($product_res as $result)
                    {
                        $sum_of_all_products = $sum_of_all_products + ($values["item_quantity"] * $result["price"]);                       
                    }
                }
                else{
                    echo 'relation not inserted';
                }            
               
            }
            $update_total_order_price_sql = "UPDATE orders SET total_price='$sum_of_all_products' WHERE id = '$ord_id'";
            $update_res = mysqli_query($conn, $update_total_order_price_sql);
            if($update_res)
            {
                unset($_COOKIE['shopping_cart']);
                setcookie('shopping_cart', "", time()-3600);
                $order_place = 1;
                // echo "Order placed!!";
                $msg = '<div class="alert alert-success" role="alert">
                            Your order is placed!!
                        </div>';
            }
            else{
                // echo "Order not placed";
                $order_place = 0;
                $msg = '<div class="alert alert-success" role="alert">
                            Order not placed!!
                        </div>';
            }

        }
        else
        {
            echo "Order not inserted";
        }
    }
    else{
        $msg ='<div class="alert alert-danger" role="alert">
                    Cart is empty;
             </div>';
    }
    $get_order_details = "SELECT * FROM orders WHERE id ='$ord_id'";
    $get_order_details_res = mysqli_query($conn, $get_order_details);
    $num_rows_orders = mysqli_num_rows($get_order_details_res);
    
    $order_details_sql = "SELECT p.title,  p.price, o.order_uid, o.total_price, op.p_quantity FROM product AS p JOIN orders_products AS op ON p.id = op.product_id AND p.status = 'Active' JOIN orders AS o ON op.order_id = o.id AND o.id='$ord_id'";    
    $order_details_res = mysqli_query($conn, $order_details_sql);
    $num_rows_order_details = mysqli_num_rows($order_details_res);

?>
<!-- Page Contain -->
<div class="page-contain mt-5 pt-5">
    <!-- Main content -->
    <div id="main-content" class="main-content">                         
        <div class="product-tab z-index-20 sm-margin-top-193px xs-margin-top-30px">
            <div class="container"> 
                <?php
                    if($order_place == 1)
                    {
                        echo $msg;
                        if ($num_rows_order_details>0)
                        {                                
                                $order_row = mysqli_fetch_assoc($get_order_details_res);           
                                echo '<h2> Order ID :'.$order_row['order_uid'].'</h4>';                        
                                $i = 1; 
                                $total_price = 0;
                                echo '<table class="table table-bordered">                    
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Product Name</th>                                                
                                                <th>Per Unit Price</th>  
                                                <th>Quantity</th> 
                                                <th>Total Price</th>                                                                                                
                                            </tr>
                                        </thead>
                                        <tbody>';
                                if($num_rows_order_details > 0)     
                                {
                                    while($product_row = $order_details_res->fetch_assoc() )
                                    {                                                             
                                        $total_price = $product_row['p_quantity'] * $product_row['price'];
                                        echo '<tr>                                        
                                                <td>'.$i.'</td>
                                                <td>'.$product_row['title'].'</td>                                           
                                                <td>'.number_format($product_row['price'], 2).'</td>      
                                                <td>'.number_format($product_row['p_quantity'], 2).'</td>                                            
                                                <td>'.number_format($total_price, 2).'</td>                                    
                                            </tr>';
                                            $i++;
                                    }
                                    echo '<tr>
                                            <td colspan="4" align="right">Total</td>
                                            <td align="right">'.number_format($order_row['total_price'], 2).'</td>                                        
                                        </tr>';  
                                }
                            echo'</tbody>
                                </table>';                                                                                                                    
                        }
                    }    
                    else{
                        echo $msg;
                    }            
                ?>
            </div>
        </div>
    </div>
</div>
<?php
include("header_customer.php");
include("footer.php");
?> 