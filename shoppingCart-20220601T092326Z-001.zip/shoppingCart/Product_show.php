<?php
session_start();
if(!isset($_SESSION['username']) || $_SESSION['username']=''){
  header('location: admin.php');
  exit();
}
?>


<?php
include("database.php");
$sql = "SELECT DISTINCT(name),id FROM categorys";
// print_r($sql);
$result = mysqli_query($conn, $sql);
// print_r($result);

include("header.php");
?>


<body>
<!--Add Modal -->
<div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Data</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <form action="product_add_php.php" method="Post" enctype="multipart/form-data">
        <div class="modal-body">
       
            <label for="">Category Select</label>
            <select name="category[]" id="" multiple>
                <?php
                    if($result > 0)
                    {
                        while($category_id = $result->fetch_assoc()){
                            echo '<option value="'.$category_id['id'].'">'.$category_id['name'].'</option>';                                                                
                        }
                    }
                ?>
            </select>
            <br>
            <br>
            <label for="">Product Title</label>
            <input type="name" class="mb-5" name="title" value="">
            <br>
            <label for="">Product Image</label>
            <input type="file" class="mb-5" name="product_img" value="">
            <br>
            <label for="">Description</label>
            <input type="name" class="mb-5" name="description" value="">
            <br>
            <label for="">Product Price</label>
            <input type="name" class="mb-5" name="price" value="">
            <br>
            <label for="">Stock</label>
            <input type="name" class="mb-5" name="stock" value="">
            <br>
            <label for="">status</label>
            <input type="name" class="mb-5" name="status" value="">
            <br>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
          <button class=" btn btn-primary" type="submit" name="submit" id="myBtn"><b>Product Add</b></button>
        </div>
      </form>
    </div>
  </div>
</div>


<div class="container mt-5 pt-5">
  <div class="jumbotron">
      <div class="card">
        <h3>Product List</h3>		
      </div>
      <div class="card">
        <div class="card-body">
           <!-- Button trigger modal -->
          <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addModal">
            Add Data
          </button>
        </div>	
      </div>
      <div class="card">
        <div class="card-body">
        <table class="table table-striped table-success table-hover">
            <thead>
            <tr>
            <th>id</th>  
            <th>Title</th>
            <th>Category</th>
            <th>Description</th>
            <th>product_img </th>
            <th>price</th>
            <th>stock</th>
            <th>status</th>
            <th>Create Date</th>
            <th>Update Date</th>
            <th>Edit </th>
            <th>Delete</th>
            </tr>
            </thead>

            <?php
            include("database.php");

            $sql= "select * from product";
            $result=$conn->query($sql) ;
           

            while($row = mysqli_fetch_array($result))
            {

            $image = $row["product_img"];
            $imgpath = 'images'.'/'.$image;
            $id = $row['id'];
            $sql_show = "SELECT name FROM categorys WHERE id IN (SELECT category_id FROM product_category WHERE product_id ='$id')";
            $results = mysqli_query($conn, $sql_show);
            $row_category = mysqli_num_rows($results);
            // print_r($sql);
            ?>
            <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['title']; ?></td>

            <td>
            <?php
            $i=1;
                if($row_category>0){
                  while($category_name = $results->fetch_assoc()){
                      echo $category_name['name']; ?><br><?php
                      $i++;                                                               
                  } 
                }
            ?>

            </td>


            <td><?php echo $row['description']; ?></td>
            <td><img src="<?php echo $imgpath; ?>" style="width:80px; height:80px;"></td>
            <td><?php echo $row['price']; ?></td>
            <td><?php echo $row['stock']; ?></td>
            <td><?php echo $row['status']; ?></td>
            <td><?php echo $row['create_date']; ?></td>
            <td><?php echo $row['update_date']; ?></td> 
            <td> 

              <a class="btn btn-primary " href="product_edit.php? id=<?php echo $row['id']; ?> & title=<?php echo $row['title']; ?> 
              & description=<?php echo $row['description'];?> 
              & image=<?php echo $image; ?> 
              & price=<?php echo $row['price']; ?>
              & stock=<?php echo $row['stock']; ?>
              & status=<?php echo $row['status']; ?>">Edit</a>    
                
            </td>
            <td>
            <button class="btn btn-danger delete_button">
                    <?php echo '<a class="btn-danger" href="delete_product_php.php?deleteid='.$id.'">Delete</a>'?>
                </button>
            </td>
            </tr>
            <?php
            }
            ?>
            </table>
        </div>
      </div>
  </div>
</div>

<!-- jquery cdn  -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!-- bootstrap js link  -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
   

<!-- edit data  -->
<script>
$(document).ready(function(){
    $('.editbtn').on('click', function(){
      $('#editmodal').model('show');
        $tr = $(this).closest('tr');
        var data = $tr.children("td").map(function(){
          return $(this).text();
        }).get();
        console.log(data);
        $('#update_id').val(data[0]);
        $('#name').val(data[0]);
        $('#description').val(data[0]);
        $('#status').val(data[0]);
    });
});
</script>


<script>
    $(document).on('click','.delete_button',function(event){
        if(!confirm("Do you want to  delete this data?")) {
        return false}
    });
  </script>

</body>
<?php
include("footer.php");
?>
</html>
