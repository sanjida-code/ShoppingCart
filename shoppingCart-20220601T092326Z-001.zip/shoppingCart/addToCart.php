
<div class="container my-5 ">
<div class="row my-5 pt-5 text-centerpy-3">

<?php
    include("database.php");

    $sql= "select * from product";
    $result=$conn->query($sql) ;
    
    while($row = mysqli_fetch_array($result))
    {

        $image = $row["product_img"];
        $imgpath = 'images'.'/'.$image;
        $id = $row['id'];
        $sql_show = "SELECT name FROM categorys WHERE id IN (SELECT category_id FROM product_category WHERE product_id ='$id')";
        $results = mysqli_query($conn, $sql_show);
        $row_category = mysqli_num_rows($results);
        // print_r($sql);
?>
    <!-- Product Show  -->
    <div class="col-md-3 col-sm-6 my-3 my-md-0">
        <form action="cart.php" method="POST">
            <div class="card shadow">
                <div>
                <img src="<?php echo $imgpath; ?>" style="width:180px; height:180px;">
                </div>
                <div class="card-body">
                    <h5 class="card-title"><?php echo $row['title']; ?></h5>
                    <h6>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </h6>
                    <p class="card-text"><?php echo $row['description']; ?></p>
                    <h5>
                        <span class= "price">Price: $<?php echo $row['price']; ?></span>
                    </h5>
                    <h5 class="card-title">Stock: <?php echo $row['stock']; ?></h5>
                    <h5 class="card-title">Status: <?php echo $row['status']; ?></h5>
                    <input type="number" name="quantity" value="1" class="form-control"/>
                    <input type="hidden" name="hidden_name" value="<?php echo $row['title']; ?>">
                    <input type="hidden" name="hidden_price" value="<?php echo $row['price']; ?>"/>
                    <input type="hidden" name="hidden_id" value="<?php echo $row['id']; ?>"/>
                    
                    <input type="submit" name ="add_to_cart" class = "btn btn-primary w-100 p-3" value ="Add To Cart"/>
                </div>
            </div>
        </form>
    </div>  
<?php
    }
?>
    </div>
</div>
</table>
<?php
    include("header_customer.php");
?>
<!-- bootstrap js link  -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<?php
include("footer.php");
?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>
