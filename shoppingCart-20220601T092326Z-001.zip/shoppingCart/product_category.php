<?php
session_start();
if(!isset($_SESSION['username']) || $_SESSION['username']=''){
  header('location: admin.php');
  exit();
}
?>
<?php
include("header.php");
?>
<body>


<!--Add Modal -->
<div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Data</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <form class="m-5 p-5" action="category_add_php.php" method="Post">
        <div class="modal-body">
            <label for="">Category Name</label>
            <input type="name" class="mb-5" name="name" value="">
            <br>
            <label for="">Description</label>
            <input type="name" class="mb-5" name="description" value="">
            <br>
            <label for="">status</label>
            <input type="name" class="mb-5" name="status" value="">
            <br>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
          <button class=" btn btn-primary" type="submit" name="submit" id="myBtn"><b>Category Add</b></button>
        </div>
      </form>
    </div>
  </div>
</div>


<div class="container mt-5 pt-5">
  <div class="jumbotron">
      <div class="card">
        <h3>Category List</h3>		
      </div>
      <div class="card">
        <div class="card-body">
           <!-- Button trigger modal -->
          <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addModal">
            Add Data
          </button>
        </div>	
      </div>
      <div class="card">
        <div class="card-body">
          <table class="table table-striped table-success table-hover">
              <thead>
              <tr>
              <th>Category_id</th>
              <th>Product_id</th>
              <th>Create Date</th>
              <th>Update Date</th>
              </tr>
              </thead>

              <?php
              include("database.php");
              $sql= "select * from product_category";
              $result=$conn->query($sql) ;

              while($row = mysqli_fetch_array($result))
                {
              ?>
                <tr id="<?php echo $row['id']; ?>">
                <td><?php echo $row['category_id']; ?></td>
                <td><?php echo $row['product_id']; ?></td>
                <td><?php echo $row['create_date']; ?></td>
                <td><?php echo $row['update_date']; ?></td> 
                </tr>
                <?php
                }
                ?>
            </table>
        </div>
      </div>
  </div>
</div>

<!-- jquery cdn  -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!-- bootstrap js link  -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>

</body>
<?php
include("footer.php");
?>
</html>
