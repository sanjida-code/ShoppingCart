<?php
session_start();
if(!isset($_SESSION['username']) || $_SESSION['username']=''){
	header('location: admin.php');
	exit();
  }
?>
<?php
include("database.php");

		if(!mysqli_select_db($conn, 'shopping'))
		{
			echo 'database not selected';
		}
		
if(isset($_POST['submit'])){		
        $title =$_POST['title']; 
		// $product_img =$_POST['product_img']; 

		$filename = $_FILES["product_img"]["name"];
        $tempname = $_FILES["product_img"]["tmp_name"];    
        $folder = "images/".$filename;

		$description = $_POST['description'];
		$price =$_POST['price'];
		$stock = $_POST['stock'];
		$status = $_POST['status'];

 $sql= "insert into product set title='$title', product_img = '$filename', description = '$description', price = '$price', stock = '$stock', status ='$status'";
 //print_r($sql);
 $result=$conn->query($sql) ;
 if($result){
	 echo "form submitted";
			if (move_uploaded_file($tempname, $folder))  {
				$msg = "Image uploaded successfully";

				$product_id = mysqli_insert_id($conn);
                   
				if(isset($_POST['category']))
				{
					foreach($_POST['category'] as $category_id)
					{
						$sql_add = "INSERT INTO product_category SET category_id='$category_id', product_id='$product_id'"; //insert in category product relation table
						$result_add = mysqli_query($conn, $sql_add); 
						print_r($result_add);
					}
					if($result_add == 1)
					{
						$_SESSION['msg'] = 'Product added successfully';
						header("Location: Product_show.php");
					}
					else{
						$msg="Failed to add relation";
					}  
				}

			}
			else{
				$msg = "Failed to upload image";
		  	}
 }
 else{
	 echo "form not submitted";
 }
}
 header("refresh:1 url= Product_show.php");
?>