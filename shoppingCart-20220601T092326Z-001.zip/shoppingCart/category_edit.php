<?php
session_start();
if(!isset($_SESSION['username']) || $_SESSION['username']=''){
    header('location: admin.php');
    exit();
  }
?>
<?php
include("header.php");
include("database.php");
$id=$_GET['id'];
$name=$_GET['name'];
$description=$_GET['description'];
$status=$_GET['status'];
?>
<body>
    <h1 class="text-center mt-5">Category update</h1>
    <form class="m-5 p-5" action="category_edit_php.php" method="Post">
        <label for="">Category ID</label>
        <input type="name" class="mb-5" name="id" value="<?php echo "$id" ?>">
        <br>        
        <label for="">Category Name</label>
        <input type="name" class="mb-5" name="name" value="<?php echo "$name" ?>">
        <br>
        <label for="">Description</label>
        <input type="name" class="mb-5" name="description" value="<?php echo "$description" ?>">
        <br>
        <label for="">status</label>
        <input type="name" class="mb-5" name="status" value="<?php echo "$status" ?>">
        <br>
        <a class=" btn btn-secondary" href="category_show.php">No</a>
        <button class=" btn btn-primary" type="submit" name="submit" id="myBtn"><b>Category update</b></button>
</form>
<?php
include("footer.php");
?>
</body>
</html>