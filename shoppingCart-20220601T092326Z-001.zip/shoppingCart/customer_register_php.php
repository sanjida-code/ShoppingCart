<?php
include("database.php");

if(isset($_POST['submit'])){		
		$name =$_POST['name'];
		$email = $_POST['email'];
		$password =md5($_POST['password']);

 $sql= "insert into customer set name='$name', email ='$email', password='$password' ";
//  print_r($sql);
 $result=$conn->query($sql) ;
 if($result){
	 echo "Data Add";
 }
 else{
	 echo "form not submitted";
 }
}
 header("location: addToCart.php");
?>