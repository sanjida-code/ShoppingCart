<?php
include("header.php");
?>
<body>
    <h1 class="text-center mt-5">Product add</h1>
    <form class="m-5 p-5" action="product_add_php.php" method="Post" enctype="multipart/form-data">
        <label for="">Product Title</label>
        <input type="name" class="mb-5" name="title" value="">
        <br>
        <label for="">Product Image</label>
        <input type="file" class="mb-5" name="product_img" value="">
        <br>
        <label for="">Description</label>
        <input type="name" class="mb-5" name="description" value="">
        <br>
        <label for="">Product Price</label>
        <input type="name" class="mb-5" name="price" value="">
        <br>
        <label for="">Stock</label>
        <input type="name" class="mb-5" name="stock" value="">
        <br>
        <label for="">status</label>
        <input type="name" class="mb-5" name="status" value="">
        <br>
        <button class=" btn btn-primary" type="submit" name="submit" id="myBtn"><b>Product Add</b></button>
</form>
<?php
include("footer.php");
?>
</body>
</html>