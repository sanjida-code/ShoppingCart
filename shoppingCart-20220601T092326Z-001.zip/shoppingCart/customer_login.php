<?php
include("header_customer.php");
?>
<body>
<section class="h-100 gradient-form mt-5" style="background-color: #eee;">
  <div class="container py-5 h-100 mt-5">
    <div class=" d-flex justify-content-center align-items-center h-100">
      <div>
        <div class="card rounded-3 text-black">
          <div class="g-0">
            <div>
              <div class="card-body p-md-5 mx-md-4">

                <form action="customer_login_php.php" method="POST">
                  <h3>Please login to your account</h3>

                  <div class="form-outline my-4">
                    <label class="form-label" for="form2Example11">Username</label> 
                    <input type="text" id="form2Example11" name="name" class="form-control" placeholder="Enter Username"/>
                  </div>

                  <div class="form-outline mb-4">
                    <label class="form-label" for="form2Example22">Password</label>
                    <input type="password" id="psw" name="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" placeholder="Enter Password" id="form3Example4c" class="form-control" required><br>
                    <input type="checkbox" onclick="myFunction()"style="text-align:right;">Show Password<br>
                  </div>

                  <div class="text-center pt-1 mb-5 pb-1">
                  <button class="btn btn-primary " type="submit" name="submit" id="myBtn"><b>Sign in</b></button>
                  <a class="btn btn-primary" href="customer_logout.php"><b>Sign Out</b></a>
                  </div>

                  <div class="d-flex align-items-center justify-content-center pb-4">
                    <p class="mb-0 me-2">Don't have an account? <a href="customer_register.php">Sign Up</a> </p> 
                  </div>

                </form>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- password show  -->
<script>
function myFunction() {
  var x = document.getElementById("psw");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>


<!-- bootstrap js -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>


</body>
<?php
include("footer.php");
?>
</html>