<?php
$servername="localhost" ;
$serveruser="root" ;
$serverpass="" ;
$DBname="shopping" ;
$conn=mysqli_connect($servername , $serveruser , $serverpass , $DBname ) ;
// if(!$conn)
//     die("error in connection") ;
// else
//     echo "ok done </br>" ;
?>