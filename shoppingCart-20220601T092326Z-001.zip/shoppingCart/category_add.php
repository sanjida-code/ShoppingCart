<?php
include("header.php");
?>
<body>
    <h1 class="text-center mt-5">Category add</h1>
    <form class="m-5 p-5" action="category_add_php.php" method="Post">
        
        <label for="">Category Name</label>
        <input type="name" class="mb-5" name="name" value="">
        <br>
        <label for="">Description</label>
        <input type="name" class="mb-5" name="description" value="">
        <br>
        <label for="">status</label>
        <input type="name" class="mb-5" name="status" value="">
        <br>
        <button class=" btn btn-primary" type="submit" name="submit" id="myBtn"><b>Category Add</b></button>
</form>
<?php
include("footer.php");
?>
</body>
</html>