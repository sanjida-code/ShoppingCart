<?php
session_start();
require('database.php');

if(empty($_SESSION['username'])){

		if(isset($_POST['submit'])){
			
			$name=$_POST['name'];
			$password=md5($_POST['password']);

			$sql= "select * from customer where name='".$name."' AND password='".$password."' ";
			$result=$conn->query($sql) ;
			$row = mysqli_fetch_array($result);
			if($row['name'] == $name && $row['password'] == $password)
			{
				
				$username = $row['name'];
				$id = $row['id'];

				$_SESSION['username'] = $username;
				$_SESSION['id'] = $id;

				// echo $_SESSION['id'];
				// exit();

			header('location: addToCart.php');
			}
			else{
				echo "Please enter correct username and password";
				exit();
			}
		}
		else{
			echo "you input correct value";
			exit();
		}
	}
else{
	header('location: customer_register_php.php');
}
?>