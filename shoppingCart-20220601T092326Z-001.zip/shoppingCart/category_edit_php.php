<?php
session_start();
if(!isset($_SESSION['username']) || $_SESSION['username']=''){
	header('location: admin.php');
	exit();
  }
?>
<?php
include("database.php");

		if(!mysqli_select_db($conn, 'shopping'))
		{
			echo 'database not selected';
		}
if(isset($_POST['submit'])){		
        $id =$_POST['id'];
		$name =$_POST['name'];
		$description = $_POST['description'];
		$status = $_POST['status'];

$sql= "UPDATE categorys SET name = '$name', description = '$description', status ='$status' WHERE id = '$id' ";
$result=$conn->query($sql) ;
 if($result){
	 echo "form submitted";
 }
 else{
	 echo "form not submitted";
 }
}
 header("refresh:2 url= category_show.php");
?>