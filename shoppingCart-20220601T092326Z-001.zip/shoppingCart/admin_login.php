<?php
session_start();
require('database.php');

if(empty($_SESSION['username'])){

		if(isset($_POST['username'])){
			
			$username=$_POST['username'];
			$password=md5($_POST['password']);

			$sql= "select * from admin where username='".$username."' AND password='".$password."' ";
			$result=$conn->query($sql) ;
			$row = mysqli_fetch_array($result);
			if($row['username'] == $username && $row['password'] == $password)
			{
				
				$username = $row['username'];
				
				$_SESSION['username'] = $username;

				// echo $_SESSION['username'];

			header('location: adminhome.php');
			}
			else{
				echo "Please enter correct username and password";
				exit();
			}
		}
		else{
			echo "you input correct value";
			exit();
		}
	}
else{
	header('location: adminhome.php');
}
?>