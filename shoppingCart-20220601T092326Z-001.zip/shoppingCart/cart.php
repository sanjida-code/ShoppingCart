<?php
// session_start();

include("database.php");

if(isset($_POST["add_to_cart"]))
{
    if(isset($_COOKIE["shopping_cart"]))
    {
        $cookie_data = stripcslashes($_COOKIE['shopping_cart']);
        $cart_data = json_decode($cookie_data, true);
    }
    else
    {
        $cart_data = array();
    }
    $item_id_list = array_column($cart_data, 'item_id');

    if(in_array($_POST["hidden_id"], $item_id_list))
    {
        foreach($cart_data as $keys => $values)
        {
            if($cart_data[$keys]["item_id"] == $_POST["hidden_id"])
            {
                $cart_data[$keys]["item_quantity"] = $cart_data[$keys]["item_quantity"] + $_POST["quantity"];
            }
        }
    }
    else
    {
        $item_array =array(
            'item_id'       => $_POST["hidden_id"],
            'item_name'     => $_POST["hidden_name"],
            'item_price'    => $_POST["hidden_price"],
            'item_quantity' => $_POST["quantity"]
        );
        $cart_data[] = $item_array;
    }

    $item_data = json_encode($cart_data);
    setcookie('shopping_cart', $item_data, time() + (86400 * 30));
    header("location: cart.php?success=1");
}

    if(isset($_GET["action"]))
    {
        if($_GET["action"] == "delete")
        {
            $cookie_data =   stripcslashes($_COOKIE["shopping_cart"]);
            $cart_data = json_decode($cookie_data, true);
            foreach($cart_data as $keys => $values)
            {
                if($cart_data[$keys]['item_id'] == $_GET["id"])
                {
                    unset($cart_data[$keys]);
                    $item_data = json_encode($cart_data);
                    setcookie("shopping_cart", $item_data, time() + (86400 * 30));
                    header("location:cart.php?remove=1");
                }
            }
        }
    }
// <!-- Update  -->


if(isset($_POST['submit']))
{
    echo'yes';
    $qan_price_array = array(
        'quantity' => $_POST['newquantity'],
        'price' => $_POST['price'],
        'total_price' => $_POST['total_price'],
        'id' => $_POST['pid'],
    );
    $qan_price[] = $qan_price_array;

    if(isset($_COOKIE["shopping_cart"]))
    {
        $cookie_data = stripcslashes($_COOKIE['shopping_cart']);
        $cart_data = json_decode($cookie_data, true);
    }
    else
    {
        $cart_data = array();
    }
    foreach($cart_data as $cart => $values)
    {
        foreach($qan_price as $key => $values)
        {
            foreach($qan_price[$key]['id'] as $key2 => $values2)
            {
                if($cart_data[$cart]['item_id'] == $qan_price[$key]['id'][$key2])
                {
                    $cart_data[$cart]['item_quantity'] = $qan_price[$key]['quantity'][$key2];
                    $total_price = $qan_price[$key]['price'][$key2] * $qan_price[$key]['quantity'][$key2];
                }
            }
        }
    }
    $item_data = json_encode($cart_data);
    setcookie("shopping_cart", $item_data, time() + (86400 * 30));
    // print_r($cart_data);
    // exit();
    $_SESSION['update_msg'] = 'Your cart is updated!!';
    header("location:cart.php");
}
?>


<div class="m-5 p-2">
<h3>Order Details</h3>
<?php
// echo $message; 
?>
<table class="table table-bordered">
    <tr>
        <th>Id</th>
        <th>Item Name</th>
        <th>Quantity</th>
        <th>Price</th>
        <th>Total</th>
        <th>Action</th>
    </tr>
    <?php
        
        if(isset($_COOKIE["shopping_cart"]))
        {
            $i=1;
            $total = 0;
            $cookie_data = stripcslashes($_COOKIE['shopping_cart']);
            $cart_data = json_decode($cookie_data, true);
    ?>
    <!--update form start  -->
            <form action="cart.php" method="Post">
            <input type="submit" name="submit" class="btn btn-primary" value="Update">
        <?php  
            foreach($cart_data as $keys => $values)
            {
                $p_sql = "SELECT * FROM product WHERE id =".$values['item_id'];
                $p_result = mysqli_query($conn, $p_sql);
                $num_rows_product = mysqli_num_rows($p_result);
                foreach($p_result as $result)
                    {
                    $total_price = $values['item_quantity'] * $result['price'];
                    echo '
                    <input type="hidden" name="pid[]" value="'.$result['id'].'">
                    <tr>
                        <td>'.$i.'</td>
                        <td>'.$result['title'].'</td>
                        <td class="w-25"><input type="number" min=1 name = "newquantity[]" value="'.$values["item_quantity"].'"></td>
                        <td>'.number_format($result['price'], 2).'</td>
                        <input type="hidden" name="price[]" value="'.$result['price'].'">
                        <td>'.number_format($total_price, 2).'</td>
                        <input type="hidden" name="total_price[]" value="'.$total_price.'">
                        <td><a href="cart.php?action=delete&id= '.$values["item_id"].'"> Remove</td> 
                    </tr>
                    ';
                  $i++;
                $total = $total +($values["item_quantity"] * $values["item_price"]);
                 }
              
            }
            echo '
            <tr>
                <td colspan="4">Total</td>
                <td>$ '.number_format($total, 2).'</td>
                <td></td>
            </tr>
            </form>            
            ';
        }
        else
        {
            echo '
                <tr>
                    <td colspan="5" align="center"> No Item in Cart</td>
                </tr>
            ';
        }
    ?>
    </table> 
 <a class="btn btn-primary" href="checkout.php">Checkout</a> 
</div>
<?php
include("header_customer.php");
include("footer.php");
?> 
</body>
</html>