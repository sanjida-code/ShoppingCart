<footer>
<h2 class="text-white text-center">trenzasoft@gmail.com</h2>
<h5 class="text-white text-center">Mogbazar, Dhaka</h5>
<section class="footer">
<p style="text-align:center; color:aliceblue">Made with <i class="fa fa-heart-o"></i> by Sanjida Akter</p>
</section>
</footer>