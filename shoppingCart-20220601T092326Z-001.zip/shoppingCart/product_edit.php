<?php
session_start();
if(!isset($_SESSION['username']) || $_SESSION['username']=''){
    header('location: admin.php');
    exit();
  }
?>
<?php
include("header.php");
include("database.php");
$id=$_GET['id'];
$title=$_GET['title'];
$description=$_GET['description'];
$image=$_GET['image'];
$imagePath = 'images'.'/'.$image;
$price=$_GET['price'];
$stock=$_GET['stock'];
$status=$_GET['status'];
?>
<body>
    <h1 class="text-center mt-5">Product add</h1>
    <form class="m-5 p-5" action="product_edit_php.php" method="Post" enctype="multipart/form-data">
        <label for="">Product Id</label>
        <input type="name" class="mb-5" name="id" value="<?php echo "$id" ?>">
        <br>
        <label for="">Product Title</label>
        <input type="name" class="mb-5" name="title" value="<?php echo "$title" ?>">
        <br>

        <label for="">Product Image</label>
        <input type="file" class="mb-5" name="product_img" value="">
        <input type="hidden" name="oldimage" value="<?php echo $image; ?>">
        <img src="<?php echo $imagePath; ?>" style="width:80px; height:80px;">
        <br>


        <label for="">Description</label>
        <input type="name" class="mb-5" name="description" value="<?php echo "$description" ?>">
        <br>
        <label for="">Product Price</label>
        <input type="name" class="mb-5" name="price" value="<?php echo "$price" ?>">
        <br>
        <label for="">Stock</label>
        <input type="name" class="mb-5" name="stock" value="<?php echo "$stock" ?>">
        <br>
        <label for="">status</label>
        <input type="name" class="mb-5" name="status" value="<?php echo "$status" ?>">
        <br>
        <a class=" btn btn-secondary" href="Product_show.php">No</a>
        <button class=" btn btn-primary" type="submit" name="submit" id="myBtn"><b>Product update</b></button>
</form>
<?php
include("footer.php");
?>
</body>
</html>