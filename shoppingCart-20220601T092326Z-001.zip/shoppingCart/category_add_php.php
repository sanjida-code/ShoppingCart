<?php
session_start();
if(!isset($_SESSION['username']) || $_SESSION['username']=''){
	header('location: admin.php');
	exit();
  }
?>
<?php
include("database.php");

		if(!mysqli_select_db($conn, 'shopping'))
		{
			echo 'database not selected';
		}
if(isset($_POST['submit'])){		
		$name =$_POST['name'];
		$description = $_POST['description'];
		$status = $_POST['status'];

 $sql= "insert into categorys set name='$name', description='$description', status='$status' ";
//  print_r($sql);
 $result=$conn->query($sql) ;
 if($result){
	 echo "Data Add";
 }
 else{
	 echo "form not submitted";
 }
}
 header("refresh:1 url= category_show.php");
?>