<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Admin Login Page</title>
    <!-- bootstrap link  -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <!-- css link  -->
    <link rel="stylesheet" href="style.css">
</head>
<body>

  <main>
  <div class="mx-auto my-5 pt-5 w-25 h-50">
    <div class= "bg-primary p-2 w-100">
    <h1 class="text-center text-white">Login Form for Admin</h1>
    </div>

    <form action="admin_login.php" method="post">

        <div class="m-5">
            <label for="username"><b>Username</b></label>
            <input class=" p-2 w-100" type="text" placeholder="Enter Username" name="username" required>
            <br>
            <label class="mt-5" for="psw"><b>Password</b></label>
            <input class=" p-2 w-100" type="password" id="psw" name="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" placeholder="Enter Password" required><br>
            <input type="checkbox" onclick="myFunction()"style="text-align:right;">Show Password<br>
            <br>
            </select>	
            <br><button class="btn btn-primary  px-5" type="submit" name="submit" id="myBtn"><b>Login</b></button>
            <a class="btn btn-primary ms-5 px-5" href="logout.php"><b>Logout</b></a>
        </div>
    </form>
    </div>
  </main>


<!-- password show  -->
<script>
function myFunction() {
  var x = document.getElementById("psw");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>


<!-- bootstrap js -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>
