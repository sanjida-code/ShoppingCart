<?php
// session_start();
// if(!isset($_SESSION['username']) || $_SESSION['username']=''){
// 	header('location: admin.php');
// 	exit();
//   }
?>
<?php
include("database.php");

 if(isset($_GET['deleteid'])){
		
	$id = $_GET['deleteid'];            
	$sql= "delete from product where id = '$id' ";
	$result=$conn->query($sql) ;

 if($result){
	 
	 $sql= "delete from product_category where product_id = '$id' ";
	 $result=$conn->query($sql);
	 
	 echo "form submitted";
 }
 else{
	 echo "form not submitted";
 }
}
//  header("refresh:1 url= Product_show.php");
?>