<?php
session_start();
if(!isset($_SESSION['username']) || $_SESSION['username']=''){
	header('location: admin.php');
	exit();
  }
?>
<?php
include("database.php");

if(isset($_GET['deleteid'])){
		
$id = $_GET['deleteid'];            
$sql= "delete from categorys where id = '$id' ";
print_r($sql);
$result=$conn->query($sql) ;
 if($result){
	 echo "form submitted";
 }
 else{
	 echo "form not submitted";
 }
}
 header("refresh:2 url= category_show.php");
?>