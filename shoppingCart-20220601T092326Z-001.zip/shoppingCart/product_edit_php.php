<?php
session_start();
if(!isset($_SESSION['username']) || $_SESSION['username']=''){
	header('location: admin.php');
	exit();
  }
?>
<?php
include("database.php");

		if(!mysqli_select_db($conn, 'shopping'))
		{
			echo 'database not selected';
		}
if(isset($_POST['submit'])){		
        $id =$_POST['id'];
		$title =$_POST['title'];
		
		$oldimage =$_POST['oldimage'];

		$filename = $_FILES["product_img"]["name"];
        $tempname = $_FILES["product_img"]["tmp_name"];    
        $folder = "images/".$filename;

		$price = $_POST['price'];
		$stock = $_POST['stock'];
		$description = $_POST['description'];
		$status = $_POST['status'];
	if($filename == ''){
		$image = $oldimage;
	}
	else{
		$image = $filename;
	}


$sql= "UPDATE product SET title = '$title', description = '$description',product_img = '$image', price = '$price', stock = '$stock', status ='$status' WHERE id = '$id' ";
$result=$conn->query($sql) ;
 if($result){
	 echo "form submitted";
 }
 else{
	 echo "form not submitted";
 }
}
 header('location: Product_show.php');
?>